#!/usr/bin/dumb-init /bin/sh

/opt/cockroach_start.sh &
#sleep 10
#/opt/cockroach_users.sh